//****************************************************************************
// MIT Media Lab - Biomechatronics
// Jean-Francois (Jeff) Duval
// jfduval@media.mit.edu
// 06/2016
//****************************************************************************
// main_fsm: Contains all the case() code for the main FSM
//****************************************************************************

//****************************************************************************
// Include(s)
//****************************************************************************

#include "main.h"
#include "main_fsm.h"
#include <stdlib.h>

//****************************************************************************
// Variable(s)
//****************************************************************************

uint8 eL0 = 0, eL1 = 0, eL2 = 0;
uint16 safety_delay = 0;
uint8 new_cmd_led = 0;
uint8_t tmp_rx_command_485[PAYLOAD_BUF_LEN];
uint8_t tmp_rx_command_usb[PAYLOAD_BUF_LEN];
uint8 toggle_wdclk = 0;	
uint8 cmd_ready_485 = 0, cmd_ready_usb = 0;	
int steps = 0, current_step = 0;

//****************************************************************************
// Private Function Prototype(s):
//****************************************************************************	

//****************************************************************************
// Public Function(s)
//****************************************************************************

//1kHz time slots:
//================

#define FAKE_IMU_STEP	25
#define FAKE_IMU_MAX	10000

//Case 0: I2C_0
void main_fsm_case_0(void)
{
	imu.accel.x+=FAKE_IMU_STEP;
	if(imu.accel.x > FAKE_IMU_MAX)
		imu.accel.x = -FAKE_IMU_MAX;	
	imu.accel.y+=FAKE_IMU_STEP;
	if(imu.accel.y > FAKE_IMU_MAX)
		imu.accel.y = -FAKE_IMU_MAX;	
	imu.accel.z+=FAKE_IMU_STEP;
	if(imu.accel.z > FAKE_IMU_MAX)
		imu.accel.z = -FAKE_IMU_MAX;	
}

//Case 1: I2C_1
void main_fsm_case_1(void)
{
	int myRand = 0;
	srand(Timer_1_ReadCounter());
	myRand = rand();
	myRand %=15;
	
	ctrl.current.actual_val = 250+myRand;
}

//Case 2:
void main_fsm_case_2(void)
{
	static uint8 div = 0;
	
	div++;
	div%=50;
	if(!div)
	{
		imu.gyro.x = output_sine(PHASE1, 5000) -  5000;
		imu.gyro.y = output_sine(PHASE2, 5000) -  5000;
		imu.gyro.z = output_sine(PHASE3, 5000) -  5000;
	}
}

//Case 3: Strain Gauge DelSig ADC, SAR ADC
void main_fsm_case_3(void)
{

}

//Case 4: User Interface
void main_fsm_case_4(void)
{

}

//Case 5: Position sensors & Position setpoint
void main_fsm_case_5(void)
{
	
}

//Case 6: P & Z controllers, 0 PWM
void main_fsm_case_6(void)
{
	//static uint8 myVar = 0;
	//SPIM_1_WriteTxData(myVar++);
	
		static uint8 myVar = 0;
	uint8 numb = 0;
	
	/*
	//NSS_Write(0);
			//Test packet:
		numb = tx_cmd_data_read_all(FLEXSEA_EXECUTE_1, CMD_READ, payload_str, PAYLOAD_BUF_LEN);
    	numb = comm_gen_str(payload_str, comm_str_usb, PAYLOAD_BUF_LEN);
    	numb = COMM_STR_BUF_LEN;
		SPIM_1_PutArray(comm_str_usb, numb);
	*/
}

//Case 7:
void main_fsm_case_7(void)
{
//NSS_Write(1);
}

//Case 8: SAR ADC filtering
void main_fsm_case_8(void)
{
	
}

//Case 9: User functions & 1s timebase	
void main_fsm_case_9(void)
{

	
	//1s timebase:
	if(timebase_1s())
	{
		//Insert code that needs to run every second here
		
		//Toggle LED
		if(LED_Read())
			LED_Write(0);
		else
			LED_Write(1);
			
			

	}
}

//10kHz time slot:
//================

void main_fsm_10kHz(void)
{
	uint8 i = 0;
	unsigned char result = 0;
	uint8_t info[2] = {0,0};
	
	//RS-485 Byte Input
	#ifdef USE_RS485			

	//Data received via DMA
	if(data_ready_485)
	{
		data_ready_485 = 0;
		//Got new data in, try to decode
		cmd_ready_485 = unpack_payload_485();
	}
		
	#endif	//USE_RS485
	
	//USB Byte Input
	#ifdef USE_USB			

	get_usb_data();
	
	if(data_ready_usb)
	{
		data_ready_usb = 0;
		//Got new data in, try to decode
		cmd_ready_usb = unpack_payload_usb();
		
		eL1 = 1;
	}

	#endif	//USE_USB
	
	//FlexSEA Network Communication
	#ifdef USE_COMM
		
	//Valid communication from RS-485?
	if(cmd_ready_485 != 0)
	{
		cmd_ready_485 = 0;
		
		//Cheap trick to get first line	//ToDo: support more than 1
		for(i = 0; i < PAYLOAD_BUF_LEN; i++)
		{
			tmp_rx_command_485[i] = rx_command_485_1[0][i];
		}
		
		//payload_parse_str() calls the functions (if valid)
		result = payload_parse_str(tmp_rx_command_485, info);
		
		//LED:
		if(result == PARSE_SUCCESSFUL)
		{
			//Green LED only if the ID matched and the command was known
			new_cmd_led = 1;
		}
	}
	
	//Time to reply - RS-485?
	if(reply_ready_flag)
	{
		//We never replied in the same time slot:
		if(t1_time_share != reply_ready_timestamp)
		{
			rs485_puts(reply_ready_buf, reply_ready_len);	
		
			reply_ready_flag = 0;
		}
		
	}

	//Valid communication from USB?
	if(cmd_ready_usb != 0)
	{
		cmd_ready_usb = 0;
		
		//Cheap trick to get first line	//ToDo: support more than 1
		for(i = 0; i < PAYLOAD_BUF_LEN; i++)
		{
			tmp_rx_command_usb[i] = rx_command_usb[0][i];
		}
		
		//payload_parse_str() calls the functions (if valid)
		result = payload_parse_str(tmp_rx_command_usb, info);
		
		//LED:
		if(result == PARSE_SUCCESSFUL)
		{
			//Green LED only if the ID matched and the command was known
			new_cmd_led = 1;
		}
	}
	
	#endif	//USE_COMM
	
	#ifdef USE_SPI_COMMUT
	
		#if(ENC_COMMUT == ENC_AS5047)
			sensor_commut_1();
		#endif //ENC_AS5047
		
	#endif
	
	#if(MOTOR_COMMUT == COMMUT_SINE)     
/*        
        update_as5047_compensated();        
        sensor_sin_commut(as5047.angle_comp>>3, sine_commut_pwm);

    	if(current_sensing_flag)
    	{
    		current_sensing_flag = 0;
    		current_rms_1();	//Single sample
    		//current_rms_2();	//Average of 3 - doesn't work
    		
	    	if((ctrl.active_ctrl == CTRL_CURRENT) || (ctrl.active_ctrl == CTRL_IMPEDANCE))
	    	{
	    		//Current controller
	    		motor_current_pid_2(ctrl.current.setpoint_val, ctrl.current.actual_val);
	    	}
    	}
*/	    
        
	#endif	//(MOTOR_COMMUT == COMMUT_SINE)
}

//Asynchronous time slots:
//========================

void main_fsm_asynchronous(void)
{

}

//****************************************************************************
// Private Function(s)
//****************************************************************************
