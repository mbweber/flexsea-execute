#include "main.h"
#include "cyapicallbacks.h"

//Fake data:
struct imu_s imu;
struct scop safety_cop;
uint8_t minm_rgb_color = 0;
uint16 ext_strain[6];

uint8 reply_ready_buf[96];
uint8 reply_ready_flag;
uint8 reply_ready_len;
uint8 reply_ready_timestamp;

//Fake functions:
uint16 strain_read(void)
{
	return 12345;
}

uint32 MotorDirection_Control = 0;

struct as504x_s as5047, as5048b;

//Fake functions:
int32 refresh_enc_control(void){return 0;}
int32 refresh_enc_display(void){return 0;}

void qei_write(int32 val){}
int32 qei_read(void){return 0;}
void rs485_puts(uint8 *buf, uint32 len){}
void pwro_output(uint8 value){}
uint8 read_pwro(void){return 0;}

int16 output_sine(double phase, int gain)
{
	static double angle = 0;
	static double ret = 0;
	int16 output = 0;

		//if(t1_new_value == 1)
		{	
			//t1_new_value = 0;
			
			angle += STEP;
			if(angle >= (2*PI))
				angle = 0;
			ret = sin(angle + phase) + 1;
			
			output = (uint16)(ret*gain);
			
		}	
	
	return output;
}

//PSoC 4 ADC conversions:
#define P4_ADC_SUPPLY               5.0
#define P4_ADC_MAX                  2048
#define P4_T0                       0.5
#define P4_TC                       0.01

//PSoC 5 ADC conversions:
#define P5_ADC_SUPPLY               5.0
#define P5_ADC_MAX                  4096

float decoded_temp = 25.5;
uint8 temp = 0;

uint16 adc = 0;

int main(void)
{
	//Power on delay
	//power_on();	   
	
	//Prepare FlexSEA Stack:
    init_flexsea_payload_ptr();
	
	//Initialize all the peripherals
	init_peripherals();
	
	//Init SPIM module:
//    SPIM_1_Start();
	
	//Enable Global Interrupts
    CyGlobalIntEnable; 
	
	//Init fake data:
	imu.accel.x = 0;
	imu.accel.y = 2500;
	imu.accel.z = 5000;
	
	
	safety_cop.temperature = 125;
		
	safety_cop.v_vb = 125;
	safety_cop.v_vg = 175;
	
	//exec1.strain = 32768;
	ctrl.current.actual_val = 0;
	//exec1.analog[0] = 256;
	//exec1.analog[1] = 512;
    
    while(1)
    {
		if(t1_new_value == 1)
		{
			//If the time share slot changed we run the timing FSM. Refer to
			//timing.xlsx for more details. 't1_new_value' updates at 10kHz,
			//each slot at 1kHz.			
            
            t1_new_value = 0;            
			
			//Timing FSM:
			switch(t1_time_share)
			{
				case 0:                    
					main_fsm_case_0();	
					break;				
				case 1:       
					main_fsm_case_1();	
					break;				
				case 2:
					main_fsm_case_2();
					break;
				case 3:				
					main_fsm_case_3();					
					break;					
				case 4:
					main_fsm_case_4();			
					break;				
				case 5:
					main_fsm_case_5();			
					break;					
				case 6:
					main_fsm_case_6();						
					break;				
				case 7:					
					main_fsm_case_7();	
					break;				
				case 8:
					main_fsm_case_8();					
					break;
				case 9:
					main_fsm_case_9();	
					break;				
				default:
					break;
			}
			
			//Increment value, limits to 0-9
        	t1_time_share++;
	        t1_time_share %= 10;
			
			//The code below is executed every 100us, after the previous slot. 
			//Keep it short! (<10us if possible)
			main_fsm_10kHz();         
		}
		else
		{
			//Asynchronous code goes here.
			main_fsm_asynchronous();			
		}
	}
}
