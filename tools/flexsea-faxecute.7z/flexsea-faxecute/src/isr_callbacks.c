//****************************************************************************
// MIT Media Lab - Biomechatronics
// Jean-Francois (Jeff) Duval
// jfduval@media.mit.edu
// 02/2016
//****************************************************************************
// isr_callbacks: Implementation of the ISR functions
//****************************************************************************

//Important: this files goes with "cyapicallbacks.h". PSoC Creator 3.3 doesn't 
//include "cyapicallbacks.h" if I place it in /inc/... or I'm doing something
//wrong. Solution was to place it in /execute_1_0.cydsn/.

//****************************************************************************
// Include(s)
//****************************************************************************

#include "main.h"
//#include <device.h>
#include "cyapicallbacks.h"

int16 my_current_value = 0;
volatile uint8 data_ready = 0;

volatile uint8 spi_isr_state = 0;
uint16 spidata_mosi2[5];
uint16 spi_miso[5];

//****************************************************************************
// Public Function(s)
//****************************************************************************

void isr_t1_Interrupt_InterruptCallback()
{
	//Timer 1: 100us
	
	//Clear interrupt
	Timer_1_ReadStatusRegister();
	isr_t1_ClearPending();
	
	//All the timings are based on 100us slots
	//10 slots form the original 1ms timebase
	//'t1_time_share' is from 0 to 9, it controls the main FSM
	
	t1_new_value = 1;
	
	//Flag for the main code
	t1_100us_flag = 1;	
}

//Current sensing:
void isr_sar2_dma_Interrupt_InterruptCallback()
{
	volatile int32 adc_sum = 0;
	volatile int32 adc_avg = 0;
	
	//my_current_value = (int32)(adc_dma_array[0] - CURRENT_ZERO);	
	my_current_value++;
	data_ready = 1;
	//Used by the current controller, 0 centered.
	
	/*
	if((ctrl.active_ctrl == CTRL_CURRENT) || (ctrl.active_ctrl == CTRL_IMPEDANCE))
	{
		//Current controller
		motor_current_pid_2(ctrl.current.setpoint_val, ctrl.current.actual_val);
	}
	*/
}

#define SPI_TX_MAX_INDEX	1
void isr_spi_tx_Interrupt_InterruptCallback()
{
	uint16 tx[5];
	
	//Read status to clear flag:
	SPIM_1_ReadTxStatus();
	
	if(spi_isr_state < SPI_TX_MAX_INDEX)
	{
		//Read last word received:
		spi_miso[spi_isr_state] = SPIM_1_ReadRxData();
		//Next transfer:
		spi_isr_state++;
		tx[0] = spidata_mosi2[spi_isr_state];
		SPIM_1_PutArray(tx, 1);		
	}
	else
	{
		spi_miso[spi_isr_state] = SPIM_1_ReadRxData();
	}
}
