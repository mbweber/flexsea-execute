//****************************************************************************
// MIT Media Lab - Biomechatronics
// Jean-Francois (Jeff) Duval
// jfduval@mit.edu
// 02/2015
//****************************************************************************
// analog: ADC configurations, read & filter functions
//****************************************************************************

//Note: this is for the analog functionality of the expansion connector
// Current sensing and strain gauge amplification are in other files.

//****************************************************************************
// Include(s)
//****************************************************************************

#include "main.h"
#include "analog.h"

//****************************************************************************
// Variable(s)
//****************************************************************************

volatile uint16 adc1_res[ADC1_CHANNELS][ADC1_BUF_LEN];
volatile uint16 adc1_dbuf[ADC1_CHANNELS][ADC1_BUF_LEN];
volatile uint16 adc1_res_filtered[ADC1_CHANNELS];

int16 adc_dma_array[ADC2_BUF_LEN];
uint16 adc_sar1_dma_array[ADC1_BUF_LEN + 1];
volatile uint8 amux_ch = 0;

volatile uint8 current_sensing_flag = 0;

//DMA ADC SAR 1
uint8 DMA_5_Chan;
uint8 DMA_5_TD[1];

//DMA ADC SAR 2 (Current sensing)
uint8 DMA_1_Chan;
uint8 DMA_1_TD[1];

//****************************************************************************
// Function(s)
//****************************************************************************

void init_analog(void)
{
	/*
	//Analog amplifiers & multiplexer(s):
	AMux_1_Start();				//Start the MUX
	PGA_1_Start();
	PGA_2_Start();
	
	//ADC1:
	ADC_SAR_1_Start();
	adc_sar1_dma_config();
	isr_sar1_dma_Start();
	ADC_SAR_1_StartConvert();	//Start converting	ToDo Enable
	*/
}

uint16 adc_avg8(uint16 new_data)
{
	uint32 sum = 0;
	static uint16 adc_avg_buf[8] = {0,0,0,0,0,0,0,0};
	static uint8 cnt = 0;
	uint16 avg = 0;
	
	//Shift buffer and sum 7/8 terms
	for(cnt = 1; cnt < 8; cnt++)
	{
		adc_avg_buf[cnt-1] = adc_avg_buf[cnt];
		sum += adc_avg_buf[cnt-1];
	}
	adc_avg_buf[7] = new_data;
	sum += new_data;
		
	//Average
	avg = (uint16)(sum >> 3);
	
	return avg;	
}

//Filters the ADC buffer
void filter_sar_adc(void)
{
	uint8 i = 0, j = 0;
	uint32 adc_sum = 0;
	
	//For each channel:
	for(i = 0; i < ADC1_CHANNELS; i++)
	{
		//For each value in the channel:
		adc_sum = 0;
		for(j = 0; j < ADC1_BUF_LEN; j++)
		{
			//Add the values
			adc_sum += (uint32)adc1_dbuf[i][j];
		}
		
		//And divide to get mean
		adc1_res_filtered[i] = (uint16) ((uint32)adc_sum >> ADC1_SHIFT);
	}
}

//To avoid data corruption we copy the buffer during the interrupt:
void double_buffer_adc(void)
{
	uint16 i = 0, j = 0;
	
	//For each channel:
	for(i = 0; i < ADC1_CHANNELS; i++)
	{
		//For each value in the channel:
		for(j = 0; j < ADC1_BUF_LEN; j++)
		{	
			adc1_dbuf[i][j] = adc1_res[i][j];
		}
	}
}

//Returns one filtered value
int16 read_analog(uint8 ch)
{
	if(ch < ADC1_CHANNELS)
	{
		//Valid channel, return value
		return 128+128*ch;	//Fake value
		//return adc1_res_filtered[ch];
	}

	//Otherwise return 0
	return 0;
}

/*
//DMA for ADC SAR 1 transfers (Expansion, VB_SNS, etc.)
//Triggers an ISR after 9 samples
void adc_sar1_dma_config(void)
{
	DMA_5_Chan = DMA_5_DmaInitialize(DMA_5_BYTES_PER_BURST, DMA_5_REQUEST_PER_BURST,
	    HI16(DMA_5_SRC_BASE), HI16(DMA_5_DST_BASE));
	DMA_5_TD[0] = CyDmaTdAllocate();
	CyDmaTdSetConfiguration(DMA_5_TD[0], 18, DMA_5_TD[0], DMA_5__TD_TERMOUT_EN | TD_INC_DST_ADR);
	CyDmaTdSetAddress(DMA_5_TD[0], LO16((uint32)ADC_SAR_1_SAR_WRK0_PTR), LO16((uint32)adc_sar1_dma_array));
	CyDmaChSetInitialTd(DMA_5_Chan, DMA_5_TD[0]);
	CyDmaChEnable(DMA_5_Chan, 1);

}
*/

/*
//DMA for ADC SAR 2 transfers (motor current sensing)
//Triggers an ISR after X transfers
void adc_sar2_dma_config(void)
{
	#if(MOTOR_COMMUT == COMMUT_BLOCK)
		
	//5 transfers per ISR (10 bytes):	
	DMA_1_Chan = DMA_1_DmaInitialize(DMA_1_BYTES_PER_BURST, DMA_1_REQUEST_PER_BURST, 
	    HI16(DMA_1_SRC_BASE), HI16(DMA_1_DST_BASE));
	DMA_1_TD[0] = CyDmaTdAllocate();
	CyDmaTdSetConfiguration(DMA_1_TD[0], 10, DMA_1_TD[0], DMA_1__TD_TERMOUT_EN | TD_INC_DST_ADR);
	
	#else
	
	//9 transfers per ISR (18 bytes):	
	DMA_1_Chan = DMA_1_DmaInitialize(DMA_1_BYTES_PER_BURST, DMA_1_REQUEST_PER_BURST, 
		HI16(DMA_1_SRC_BASE), HI16(DMA_1_DST_BASE));
	DMA_1_TD[0] = CyDmaTdAllocate();
	CyDmaTdSetConfiguration(DMA_1_TD[0], 18, DMA_1_TD[0], DMA_1__TD_TERMOUT_EN | TD_INC_DST_ADR);
	
	#endif

	CyDmaTdSetAddress(DMA_1_TD[0], LO16((uint32)ADC_SAR_2_SAR_WRK0_PTR), LO16((uint32)adc_dma_array));
	CyDmaChSetInitialTd(DMA_1_Chan, DMA_1_TD[0]);
	CyDmaChEnable(DMA_1_Chan, 1);
}
*/

//Calculates RMS value from samples
void current_rms_1(void)
{
	volatile int sqA = 0, sqB = 0, sqC = 0;
	volatile int sqSum = 0;
	volatile int rms = 0;
	
	//For now, we use only 3 samples:
	sqA = (adc_dma_array[0]-CURRENT_ZERO) * (adc_dma_array[0]-CURRENT_ZERO);
	sqB = (adc_dma_array[1]-CURRENT_ZERO) * (adc_dma_array[1]-CURRENT_ZERO);
	sqC = (adc_dma_array[2]-CURRENT_ZERO) * (adc_dma_array[2]-CURRENT_ZERO);
	sqSum = sqA + sqB + sqC;
	rms = (int)sqrt((double)sqSum);
	
	ctrl.current.actual_val = (int32)(rms);	
}

//Calculates RMS value from samples
//Average of 3 points
void current_rms_2(void)
{
	volatile int tmp = 0, sqA = 0, sqB = 0, sqC = 0;
	//volatile int sqSum = 0;
	volatile int rms[3] = {0,0,0};
	volatile int rms_avg = 0;
	
	//Sample set #1
	tmp = (adc_dma_array[0]-CURRENT_ZERO);
	sqA = tmp * tmp;
	tmp = (adc_dma_array[1]-CURRENT_ZERO);
	sqB = tmp * tmp;
	tmp = (adc_dma_array[2]-CURRENT_ZERO);
	sqC = tmp * tmp;
	rms[0] = (int)sqrt((double)(sqA + sqB + sqC));
	
	//Sample set #2
	tmp = (adc_dma_array[3]-CURRENT_ZERO);
	sqA = tmp * tmp;
	tmp = (adc_dma_array[4]-CURRENT_ZERO);
	sqB = tmp * tmp;
	tmp = (adc_dma_array[5]-CURRENT_ZERO);
	sqC = tmp * tmp;
	rms[1] = (int)sqrt((double)(sqA + sqB + sqC));
	
	//Sample set #3
	tmp = (adc_dma_array[6]-CURRENT_ZERO);
	sqA = tmp * tmp;
	tmp = (adc_dma_array[7]-CURRENT_ZERO);
	sqB = tmp * tmp;
	tmp = (adc_dma_array[8]-CURRENT_ZERO);
	sqC = tmp * tmp;
	rms[2] = (int)sqrt((double)(sqA + sqB + sqC));
	
	//Average 3 values:
	rms_avg = (rms[0] + rms[1] + rms[2])/3;
	
	ctrl.current.actual_val = (int32)(rms_avg);	
}
