//****************************************************************************
// Dephy, Inc.
// Jean-Francois (JF) Duval
// jfduval@dephy.compare
// 08/2016
//****************************************************************************
// main: FlexSEA-Execute
//****************************************************************************

#ifndef MAIN_H_
#define MAIN_H_

//****************************************************************************
// Include(s)
//****************************************************************************

#include <project.h>
#include <math.h>
#include "stdio.h"
#include "analog.h"
#include "usb.h"
#include "main_fsm.h"
#include "motor.h"
#include "peripherals.h"
#include "control.h"
#include "misc.h"
#include "trapez.h"
#include "user.h"
#include "flexsea_board.h"
#include "../../flexsea-system/inc/flexsea_system.h"	
#include "../../flexsea-comm/inc/flexsea.h"	

//****************************************************************************
// Structure(s)
//****************************************************************************	
	
//Safety-CoP Data:
struct scop
{
	uint16 v_vb, v_vg, v_3v3;
	uint8 temperature;
	uint8 status1, status2;
};
	
//****************************************************************************
// Shared variable(s)
//****************************************************************************

//Fake data:
extern struct imu_s imu;
extern struct scop safety_cop;
extern uint8_t minm_rgb_color;
extern uint16 ext_strain[6];
extern uint32 MotorDirection_Control;

extern uint8 reply_ready_buf[96];
extern uint8 reply_ready_flag;
extern uint8 reply_ready_len;
extern uint8 reply_ready_timestamp;

extern struct as504x_s as5047, as5048b;
	
//****************************************************************************
// Prototype(s):
//****************************************************************************

int main(void);
int32 refresh_enc_control(void);
int32 refresh_enc_display(void);
void qei_write(int32 val);
int32 qei_read(void);
void rs485_puts(uint8 *buf, uint32 len);
uint16 strain_read(void);
void pwro_output(uint8 value);
uint8 read_pwro(void);
int16 output_sine(double phase, int gain);

#if defined (__GNUC__)
    asm (".global _printf_float");
#endif

//****************************************************************************
// Definition(s):
//****************************************************************************

//Sine generation
#define PI						3.14159265
#define STEPS					50
#define STEP					(PI/STEPS)
#define DELAY					100
#define PHASE1					0
#define PHASE2					(2*PI/3)
#define PHASE3					(4*PI/3)

#endif // MAIN_H_
